from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np  # Import NumPy for array manipulation


app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the pre-trained model
model = joblib.load("models/SA.pkl")

# Define the route for prediction
@app.route('/analyze', methods=['POST'])
def analyze():
    text = request.form['text']
    # Reshape the input data to a 2D array
    text_array = np.array([[text]])
    blob = model.predict(text_array)
    return render_template('result.html', blob=blob)

if __name__ == "__main__":
    app.run(debug=True)  # Run the Flask app
