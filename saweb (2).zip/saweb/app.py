from flask import Flask, render_template, request
import joblib

app = Flask(__name__)
model = joblib.load("models/SA.pkl")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    text = request.form['text']
    blob = model.predict(text)
    return render_template('result.html', blob)

if __name__ == '__main__':
    app.run(debug=True)
